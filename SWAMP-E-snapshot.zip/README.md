# SWAMP-E: Shallow-Water Atmospheric Model for Exoplanets

Written by Ekaterina Landgren and Alice Nadeau

email: ek672@cornell.edu
