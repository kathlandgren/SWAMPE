# -*- coding: utf-8 -*-
"""
Created on Fri May 21 10:46:21 2021

@author: ek672
"""

def optional_fun(a,b=5):
    
    print(a+b)
    
    return a
    

optional_fun(2,9)